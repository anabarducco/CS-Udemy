﻿using System;
using Aula9_ExP2.Entities;

namespace Aula9_ExP2
{
    class Program
    {
        static void Main(string[] args)
        {
            Comment comentario1 = new Comment("Tenha uma boa viagem!");
            Comment comentario2 = new Comment("Nossa, isso é fantástico!");
            Post post1 = new Post(
                    DateTime.Parse("21/06/2018 13:05:44"),
                    "Viajando para a Nova Zelândia",
                    "Indo visitar esse país maravilhoso!",
                    12);
            post1.AddComment(comentario1);
            post1.AddComment(comentario2);

            Comment comentario3 = new Comment("Boa noite");
            Comment comentario4 = new Comment("Que a força esteja com você");
            Post post2 = new Post(
                    DateTime.Parse("28/07/2018 23:14:19"),
                    "Boa noite pessoal",
                    "Vejo vocês amanhã",
                    5);
            post2.AddComment(comentario3);
            post2.AddComment(comentario4);

            Console.WriteLine(post1);
            Console.WriteLine(post2);
        }
    }
}
