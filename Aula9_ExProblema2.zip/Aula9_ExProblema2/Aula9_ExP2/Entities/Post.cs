﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula9_ExP2.Entities
{
    class Post
    {
        public DateTime Moment { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public int Likes { get; set; }
        public List<Comment> Comments { get; set; } = new List<Comment>();

        public Post()
        {
        }

        public Post(DateTime momento, string titulo, string conteudo, int curtidas)
        {
            Moment = momento;
            Title = titulo;
            Content = conteudo;
            Likes = curtidas;
        }

        public void AddComment(Comment comentario)
        {
            Comments.Add(comentario);
        }

        public void RemoveComment(Comment comentario)
        {
            Comments.Remove(comentario);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(Title);
            sb.Append(Likes);
            sb.Append(" Curtidas - ");
            sb.AppendLine(Moment.ToString("dd/MM/yyyy HH:mm:ss"));
            sb.AppendLine(Content);
            sb.AppendLine("Comentários:");
            foreach (Comment c in Comments)
            {
                sb.AppendLine(c.Text);
            }
            return sb.ToString();
        }
    }
}
