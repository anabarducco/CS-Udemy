﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula9_ExP2.Entities
{
    class Comment
    {
        public string Text { get; set; }

        public Comment()
        {

        }

        public Comment(string texto)
        {
            Text = texto;
        }

    }
}
