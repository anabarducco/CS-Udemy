﻿using System;

namespace Aula4_ExFixacao
{
    class Program
    {
        static void Main(string[] args)
        {
            Retangulo ret = new Retangulo();

            Console.WriteLine("Entre a largura e a altura do retangulo:");
            ret.Largura = double.Parse(Console.ReadLine());
            ret.Altura = double.Parse(Console.ReadLine());

            Console.WriteLine("Área = " + ret.Area().ToString("F2"));
            Console.WriteLine("Perímetro = " + ret.Perimetro().ToString("F2"));
            Console.WriteLine("Diagonal = " + ret.Diagonal().ToString("F2"));
        }
    }
}
