﻿using System;
using System.Globalization;
using Aula9_ExP1.Entities;
using Aula9_ExP1.Entities.Enums;

namespace Aula9_ExP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Entre com o nome do departamento: ");
            string nomeDpto = Console.ReadLine();
            Console.WriteLine("Entre com os dados do funcionário: ");
            Console.Write("Nome: ");
            string nomeFunc = Console.ReadLine();
            Console.Write("Nível (Junior/MidLevel/Senior): ");
            WorkerLevel nivelFunc = Enum.Parse<WorkerLevel>(Console.ReadLine());
            Console.Write("Salário Base: R$");
            double salFunc = double.Parse(Console.ReadLine());
            Console.Write("Quantidade de Contratos: ");
            int contratoFunc = int.Parse(Console.ReadLine());

            Department dpto = new Department(nomeDpto);
            Worker func = new Worker(nomeFunc, nivelFunc, salFunc, dpto);

            for(int i=0; i<contratoFunc; i++)
            {
                Console.WriteLine("Entre com os dados do contrato #"+(i+1)+": ");
                Console.Write("Data (dd/mm/aaaa): ");
                DateTime data = DateTime.Parse(Console.ReadLine());
                Console.Write("Valor da hora: R$");
                double valorHora = double.Parse(Console.ReadLine());
                Console.Write("Duração do contrato em horas: ");
                int horas = int.Parse(Console.ReadLine());

                HourContract contrato = new HourContract(data, valorHora, horas);
                func.AddContract(contrato);
            }

            Console.Write("Entre com o mês e ano para calcular a renda (mm/aaaa): ");
            string mes_ano = Console.ReadLine();
            int mes = int.Parse(mes_ano.Substring(0, 2));
            int ano = int.Parse(mes_ano.Substring(3));

            Console.WriteLine("Nome: " + func.Name);
            Console.WriteLine("Departamento: " + dpto.Name);
            Console.WriteLine("Renda para " + mes_ano + ": " + func.Income(ano, mes).ToString("F2"));
        }
    }
}
