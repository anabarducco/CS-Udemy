﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula9_ExP1.Entities
{
    class HourContract
    {
        public DateTime Date { get; set; }
        public double ValuePerHour { get; set; }
        public int Hours { get; set; }

        public HourContract()
        {

        }

        public HourContract(DateTime data, double valorHora, int hora)
        {
            Date = data;
            ValuePerHour = valorHora;
            Hours = hora;
        }

        public double TotalValue()
        {
            double valorTotal = ValuePerHour * Hours;
            return valorTotal;
        }
    }
}
