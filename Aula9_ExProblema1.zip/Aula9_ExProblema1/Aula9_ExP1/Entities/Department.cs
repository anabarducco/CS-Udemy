﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula9_ExP1.Entities
{
    class Department
    {
        public string Name { get; set; }

        public Department()
        {

        }

        public Department(string nome)
        {
            Name = nome;
        }
    }
}
