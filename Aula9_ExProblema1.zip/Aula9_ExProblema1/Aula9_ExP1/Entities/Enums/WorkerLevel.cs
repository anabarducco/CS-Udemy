﻿namespace Aula9_ExP1.Entities.Enums
{
    enum WorkerLevel : int
    {
        Junior = 1,
        MidLevel = 2,
        Senior = 3
    }
}
