﻿using System;
using System.Collections.Generic;
using System.Text;
using Aula9_ExP1.Entities.Enums;

namespace Aula9_ExP1.Entities
{
    class Worker
    {
        public string Name { get; set; }
        public WorkerLevel Level { get; set; }
        public double BaseSalary { get; set; }
        public Department Department { get; set; }
        public List<HourContract> Contracts { get; private set; } = new List<HourContract>();

        public Worker()
        {

        }

        public Worker(string nome, WorkerLevel nivel, double salarioBase, Department departamento)
        {
            Name = nome;
            Level = nivel;
            BaseSalary = salarioBase;
            Department = departamento;
        }

        public void AddContract(HourContract contract)
        {
            Contracts.Add(contract);
        }

        public void RemoveContract(HourContract contract)
        {
            Contracts.Remove(contract);
        }

        public double Income(int year, int month)
        {
            double soma = BaseSalary;
            foreach(HourContract contract in Contracts)
            {
                if(contract.Date.Year == year && contract.Date.Month == month)
                {
                    soma += contract.TotalValue();
                }
            }

            return soma;
        }
    }
}
