﻿using System;

namespace Aula4_Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            Funcionario a, b;
            a = new Funcionario();
            b = new Funcionario();

            Console.WriteLine("Dados do Primeiro Funcionário:");
            a.Nome = Console.ReadLine();
            a.Salario = double.Parse(Console.ReadLine());

            Console.WriteLine("Dados do Segundo Funcionário:");
            b.Nome = Console.ReadLine();
            b.Salario = double.Parse(Console.ReadLine());

            double salarioMedio = (a.Salario + b.Salario) / 2;

            Console.WriteLine("Salário Médio = R$" + salarioMedio.ToString("F2"));
        }
    }
}
