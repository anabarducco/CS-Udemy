﻿using System;
using System.Globalization;

namespace Aula5_ExFixacao
{
    class Program
    {
        static void Main(string[] args)
        {
            ContaBancaria contaBancaria = new ContaBancaria(); //declaração de uma nova conta bancária

            Console.WriteLine("Cadastre uma nova conta!");
            Console.Write("Digite os 4 dígitos da conta: ");
            int numeroConta = int.Parse(Console.ReadLine()); //lê número da conta
            Console.Write("Digite o nome do titular da conta: ");
            string nomeTitular = Console.ReadLine(); //lê nome do titular
            Console.Write("Haverá depósito inicial da conta? (S/N)"); 
            char op = char.Parse(Console.ReadLine()); //lê se terá depósito inicial ou não

            if (op == 'S' || op == 's') //se tiver inicia com valor de saldo definido pelo usuário
            {
                Console.Write("Digite o valor do depósito inicial: ");
                double saldo = double.Parse(Console.ReadLine());
                contaBancaria = new ContaBancaria(numeroConta, nomeTitular, saldo); 
            } else
            {
                if (op == 'N' || op == 'n') //se não tiver inicia com saldo = 0
                {
                    contaBancaria = new ContaBancaria(numeroConta, nomeTitular);
                }
            }

            Console.WriteLine("");
            Console.WriteLine("Dados da Conta: ");
            Console.WriteLine(contaBancaria);

            Console.WriteLine("");
            Console.WriteLine("Digite o valor do depósito: ");
            double valor = double.Parse(Console.ReadLine());
            contaBancaria.Deposito(valor);
            Console.WriteLine("Dados da Conta Atualizados: ");
            Console.WriteLine(contaBancaria);

            Console.WriteLine("");
            Console.WriteLine("Digite o valor do saque: ");
            valor = double.Parse(Console.ReadLine());
            contaBancaria.Saque(valor);
            Console.WriteLine("Dados da Conta Atualizados: ");
            Console.WriteLine(contaBancaria);
        }
    }
}
