﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace Aula5_ExFixacao
{
    class ContaBancaria
    {
        public int NumeroConta { get; private set; } //declaração número da conta; não pode ser alterado
        public string NomeTitular { get; set; } //declaração nome do titular; pode ser alterado
        public double Saldo { get; private set; } //declaração saldo inicial; só pode ser alterado por métodos

        public ContaBancaria() { }

        public ContaBancaria(int numeroConta, string nomeTitular) //construtor com saldo inicial igual a 0
        {
            NumeroConta = numeroConta;
            NomeTitular = nomeTitular;
            Saldo = 0;
        }

        public ContaBancaria(int numeroConta, string nomeTitular, double saldo):this(numeroConta, nomeTitular) //construtor com declaração do saldo inicial 
        {
            Saldo = saldo;
        }

        public void Deposito(double valor)
        {
            Saldo += valor;
        }

        public void Saque(double valor)
        {
            Saldo -= valor + 5.00;
        }

        public override string ToString()
        {
            return "Número da Conta: " + NumeroConta
                + " - Nome do Titular: " + NomeTitular
                + " , Saldo: R$" + Saldo.ToString("F2")
                + ".";
        }
    }
}
