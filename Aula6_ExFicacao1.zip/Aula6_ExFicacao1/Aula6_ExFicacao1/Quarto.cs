﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula6_ExFicacao1
{
    class Quarto
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public int Numero { get; set; }

        public override string ToString()
        {
            return Numero
                + " ocupado por "
                + Nome
                + ", "
                + Email;
        }
    }
}
