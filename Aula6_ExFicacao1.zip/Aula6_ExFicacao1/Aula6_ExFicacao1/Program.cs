﻿using System;

namespace Aula6_ExFicacao1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Quantos quartos serão alugados (1-10): ");
            int n = int.Parse(Console.ReadLine());

            Quarto[] quarto = new Quarto[n];

            for (int i=0; i<n; i++)
            {
                Console.WriteLine("Aluguel #" + (i+1));
                Console.Write("Nome: ");
                string nome = Console.ReadLine();
                Console.Write("Email: ");
                string email = Console.ReadLine();
                Console.Write("Número do Quarto (0-9): ");
                int numero = int.Parse(Console.ReadLine());

                quarto[i] = new Quarto { Nome = nome, Email = email, Numero = numero };
            }

            Console.WriteLine("Quartos Ocupados:");
            for (int i = 0; i < n; i++)
            {
                if (quarto[i].Numero != 0)
                {
                    
                    Console.WriteLine(quarto[i]);
                }
            }
        }
    }
}
