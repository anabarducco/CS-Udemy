﻿using System;

namespace Aula6_ExProblema1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insira quantas pessoas serão avaliadas: ");
            int n = int.Parse(Console.ReadLine());
            double[] vet = new double[n];

            for (int i=0; i<n; i++)
            {
                vet[i] = double.Parse(Console.ReadLine());
            }

            double media = 0.0;
            for (int i=0; i<n; i++)
            {
                media += vet[i];
            }

            media /= n;

            Console.WriteLine("A média das alturas é " + media.ToString("F2"));
        }
    }
}
