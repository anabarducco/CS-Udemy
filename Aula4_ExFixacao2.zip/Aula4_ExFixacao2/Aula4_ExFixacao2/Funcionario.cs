﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula4_ExFixacao2
{
    class Funcionario
    {
        public string Nome;
        public double SalarioBruto;
        public double Imposto;

        public double SalarioLiquido()
        {
            double salLiq = SalarioBruto - Imposto;
            return salLiq;
        }

        public void AumentarSalario(double porcentagem)
        {
            SalarioBruto += SalarioBruto * (porcentagem / 100);
        }
    }
}
