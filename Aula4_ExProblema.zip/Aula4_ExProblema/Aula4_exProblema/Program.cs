﻿using System;

namespace Aula4_exProblema
{
    class Program
    {
        static void Main(string[] args)
        {
            Produto produto = new Produto();

            Console.WriteLine("Entre com os dados do produto:");
            produto.Nome = Console.ReadLine();
            produto.Preco = double.Parse(Console.ReadLine());
            produto.Quantidade = int.Parse(Console.ReadLine());

            Console.WriteLine("Dados do produto: " + produto.Nome + ", R$" 
                + produto.Preco.ToString("F2") + ", " + produto.Quantidade 
                + "unidades, Total R$" + produto.ValorTotalEmEstoque().ToString("F2"));

            Console.WriteLine("Digite o número de produtos a serem adicionados em estoque: ");
            produto.Qtd = int.Parse(Console.ReadLine());

            produto.AdicionarProdutos(produto.Qtd);

            Console.WriteLine("Dados atualizados do produto: " + produto.Nome + ", R$"
                + produto.Preco.ToString("F2") + ", " + produto.Quantidade
                + "unidades, Total R$" + produto.ValorTotalEmEstoque().ToString("F2"));

            Console.WriteLine("Digite o número de produtos a serem removidos do estoque: ");
            produto.Qtd = int.Parse(Console.ReadLine());

            produto.RemoverProdutos(produto.Qtd);

            Console.WriteLine("Dados atualizados do produto: " + produto.Nome + ", R$"
                + produto.Preco.ToString("F2") + ", " + produto.Quantidade
                + "unidades, Total R$" + produto.ValorTotalEmEstoque().ToString("F2"));
        }
    }
}
