﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula4_exProblema
{
    class Produto
    {
        public string Nome;
        public double Preco;
        public int Quantidade;
        public int Qtd;

        public double ValorTotalEmEstoque()
        {
            double valorTotal = Preco * Quantidade;
            return valorTotal;
        }

        public void AdicionarProdutos(int Qtd)
        {
            Quantidade += Qtd;
        }

        public void RemoverProdutos(int Qtd)
        {
            Quantidade -= Qtd;
        }
    }
}
