﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula4_ExProblema
{
    class Circunf
    {
        public double Pi = 3.14;

        public double CompCirc(double raio)
        {
            double C = 2 * Pi * raio;
            return C;
        }

        public double VolCirc(double raio)
        {
            double V = 4 * Pi * (Math.Pow(raio, 3) / 3);
            return V;
        }
    }
}
