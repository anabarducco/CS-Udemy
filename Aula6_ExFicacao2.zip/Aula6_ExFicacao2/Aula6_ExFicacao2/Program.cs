﻿using System;
using System.Globalization;
using System.Collections.Generic;

namespace Aula6_ExFicacao2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite a quatidade de funcionários a serem registrados: ");
            int n = int.Parse(Console.ReadLine());

            List<Funcionario> lista = new List<Funcionario>();

            for(int i=0; i<n; i++)
            {
                Console.WriteLine("Funcionário #" + (i+1) + ": ");
                Console.Write("ID: ");
                int id = int.Parse(Console.ReadLine());
                Console.Write("Nome: ");
                string nome = Console.ReadLine();
                Console.Write("Salário: R$");
                double salario = double.Parse(Console.ReadLine());

                lista.Add(new Funcionario(id, nome, salario));
                Console.WriteLine(" ");
            }

            Console.Write("Digite o id do funcionário que terá seu salário aumentado: ");
            int procuraId = int.Parse(Console.ReadLine());

            Funcionario funcionario = lista.Find(x => x.Id == procuraId);
            if(funcionario != null)
            {
                Console.Write("Digite a porcentagem de aumento do salário: ");
                double porcentagem = double.Parse(Console.ReadLine());
                funcionario.AumentarSalario(porcentagem);
            } else
            {
                Console.WriteLine("Funcionário não encontrado.");
            }

            Console.WriteLine("Lista Atualizada dos Funcionários:");
            foreach(Funcionario obj in lista)
            {
                Console.WriteLine(obj);
            }
            
        }
    }
}
