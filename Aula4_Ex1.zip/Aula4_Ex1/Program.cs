﻿using System;

namespace Aula4_Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            Pessoa a, b;

            a = new Pessoa();
            b = new Pessoa();

            Console.WriteLine("Dados da Primeira Pessoa:");
            a.Nome = Console.ReadLine();
            a.Idade = double.Parse(Console.ReadLine());

            Console.WriteLine("Dados da Segunda Pessoa:");
            b.Nome = Console.ReadLine();
            b.Idade = double.Parse(Console.ReadLine());

            if(a.Idade > b.Idade)
            {
                Console.WriteLine("Pessoa mais velha: " + a.Nome);
            } else
            {
                if(b.Idade > a.Idade)
                {
                    Console.WriteLine("Pessoa mais velha: " + b.Nome);
                }
                else
                {
                    Console.WriteLine("As duas pessoas têm a mesma idade.");
                }
            }
        }
    }
}
