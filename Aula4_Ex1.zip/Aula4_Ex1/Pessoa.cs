﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula4_Ex1
{
    class Pessoa
    {
        public string Nome;
        public double Idade;
    }
}
