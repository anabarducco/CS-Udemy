﻿using System;

namespace Aula6_ExFicacao3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor de M: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            int[,] matriz = new int[m, n];

            for(int i = 0; i < m; i++)
            {
                for(int j = 0; j < n; j++)
                {
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("Digite o valor de X: ");
            int x = int.Parse(Console.ReadLine());

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if(x == matriz[i, j])
                    {
                        if (j > 0)
                        {
                            Console.WriteLine("À esquerda: ");
                            Console.WriteLine(matriz[i, j - 1]);
                        }
                        
                        if (j+1 < n)
                        {
                            Console.WriteLine("À direita: ");
                            Console.WriteLine(matriz[i, j + 1]);
                        }
                        
                        if (i > 0)
                        {
                            Console.WriteLine("Acima: ");
                            Console.WriteLine(matriz[i - 1, j]);
                        }
                        
                        if(i-1 < m)
                        {
                            Console.WriteLine("Abaixo: ");
                            Console.WriteLine(matriz[i + 1, j]);
                        }
                        
                    }
                }
            }
        }
    }
}
