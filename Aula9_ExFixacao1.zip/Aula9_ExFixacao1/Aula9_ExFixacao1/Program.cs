﻿using System;
using Aula9_ExFixacao1.Entities;
using Aula9_ExFixacao1.Entities.Enums;

namespace Aula9_ExFixacao1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Entre com os dados do cliente:");
            Console.Write("Nome: ");
            string nome = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write("Aniversário: ");
            DateTime aniversario = DateTime.Parse(Console.ReadLine());

            Console.WriteLine("Entre com os dados do pedido:");
            Console.Write("Status: ");
            OrderStatus status = Enum.Parse<OrderStatus>(Console.ReadLine());
            Console.Write("Quantidade de itens do pedido: ");
            int qtd = int.Parse(Console.ReadLine());

            Client cliente = new Client(nome, email, aniversario);
            Order pedido = new Order(DateTime.Now, status, cliente);

            for(int i=1; i<= qtd; i++)
            {
                Console.WriteLine("Entre com os dados do item #" + i + ": ");
                Console.Write("Nome do produto: ");
                string nomeProd = Console.ReadLine();
                Console.Write("Preço do produto: R$");
                double valor = double.Parse(Console.ReadLine());
                Console.Write("Quantidade: ");
                int qtdProd = int.Parse(Console.ReadLine());

                Product produto = new Product(nomeProd, valor);
                OrderItem item = new OrderItem(qtdProd, valor, produto);

                pedido.AddItem(item);
            }

            Console.WriteLine("Resumo do Pedido:");
            Console.Write(pedido);
        }
    }
}
