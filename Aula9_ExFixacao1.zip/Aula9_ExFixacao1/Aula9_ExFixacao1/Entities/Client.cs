﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula9_ExFixacao1.Entities
{
    class Client
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime Birth { get; set; }

        public Client()
        {

        }

        public Client(string nome, string email, DateTime aniversario)
        {
            Name = nome;
            Email = email;
            Birth = aniversario;
        }

        public override string ToString()
        {
            return Name
                + ", ("
                + Birth.ToString("dd/MM/yyyy")
                + ") - "
                + Email;
        }
    }
}
