﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula9_ExFixacao1.Entities
{
    class OrderItem
    {
        public int Quantity { get; set; }
        public double Price { get; set; }
        public Product Product { get; set; }

        public OrderItem()
        {

        }

        public OrderItem(int qtd, double preco, Product produto)
        {
            Quantity = qtd;
            Price = preco;
            Product = produto;
        }

        public double SubTotal()
        {
            double subtotal = Quantity * Price;
            return subtotal;
        }

        public override string ToString()
        {
            return Product.Name
                + ", R$"
                + Price.ToString("F2")
                + ", Quantidade: "
                + Quantity
                + ", Subtotal: R$"
                + SubTotal().ToString("F2");
        }
    }
}
