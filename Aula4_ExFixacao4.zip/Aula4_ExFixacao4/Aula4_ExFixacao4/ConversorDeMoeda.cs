﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula4_ExFixacao4
{
    class ConversorDeMoeda
    {
        public static double IOF = 0.06;
        public static double ValorReais(double cotacao, double qtd)
        {
            return cotacao * qtd + IOF*(cotacao*qtd);
        }
    }
}
