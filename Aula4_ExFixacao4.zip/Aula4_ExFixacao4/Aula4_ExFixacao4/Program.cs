﻿using System;

namespace Aula4_ExFixacao4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Qual é a cotação do dólar?");
            double cotaDolar = double.Parse(Console.ReadLine());
            Console.WriteLine("Quantos dólares você vai comprar?");
            double qtdDolar = double.Parse(Console.ReadLine());

            double total = ConversorDeMoeda.ValorReais(cotaDolar, qtdDolar);

            Console.WriteLine("Valor a ser pago em reais: R$" + total.ToString("F2"));
        }
    }
}
