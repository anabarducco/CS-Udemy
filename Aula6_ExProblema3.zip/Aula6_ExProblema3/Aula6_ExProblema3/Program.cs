﻿using System;

namespace Aula6_ExProblema3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());
            int[,] matriz = new int[n, n];

            for(int i=0; i<n; i++)
            {
                for(int j=0; j<n; j++)
                {
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            int[] diagPrincipal = new int[n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if(i == j)
                    {
                        diagPrincipal[i] = matriz[i, j];
                    }
                }
            }

            int totalNeg = 0;
            
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (matriz[i, j] < 0)
                    {
                        totalNeg++;
                    }
                }
            }

            Console.WriteLine("Diagonal Principal: ");
            foreach(int obj in diagPrincipal)
            {
                Console.WriteLine(obj);
            }

            Console.WriteLine("Valores Negativos = " + totalNeg);
        }
    }
}
