﻿using System;

namespace Aula4_ExFixacao3
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno = new Aluno();

            Console.WriteLine("Digite os dados do aluno:");
            Console.Write("Nome: ");
            aluno.Nome = Console.ReadLine();
            Console.WriteLine("Digite as três notas do aluno:");
            aluno.Nota1 = double.Parse(Console.ReadLine());
            aluno.Nota2 = double.Parse(Console.ReadLine());
            aluno.Nota3 = double.Parse(Console.ReadLine());


            Console.WriteLine("Nota Final: " + aluno.NotaFinal().ToString("F2"));
            if (aluno.NotaFinal() < 60)
            {
                Console.WriteLine("Reprovado.");
                Console.WriteLine("Faltaram " + aluno.NotaFaltante().ToString("F2") + " pontos.");
            } else
            {
                Console.WriteLine("Aprovado.");
            }
        }
    }
}
