﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula4_ExFixacao3
{
    class Aluno
    {
        public string Nome;
        public double Nota1;
        public double Nota2;
        public double Nota3;

        public double NotaFinal()
        {
            double notaFinal = Nota1 + Nota2 + Nota3;
            return notaFinal;
        }

        public double NotaFaltante()
        {
            double notaFaltante = 60 - (Nota1 + Nota2 + Nota3);
            return notaFaltante;
        }
    }
}
