﻿using System;

namespace Aula6_ExProblema2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Quantos produtos serão armazenados? ");
            int n = int.Parse(Console.ReadLine());
            Produto[] vet = new Produto[n];

            for(int i=0; i<n; i++)
            {
                Console.WriteLine("Insira os dados do produto " + (i+1));
                string nome = Console.ReadLine();
                double preco = double.Parse(Console.ReadLine());
                vet[i] = new Produto { Nome = nome, Preco = preco };
            }

            double precoMedio = 0.0;

            for (int i=0; i<n; i++)
            {
                precoMedio += vet[i].Preco;
            }

            precoMedio /= n;

            Console.WriteLine("Preço médio dos produtos = R$" + precoMedio.ToString("F2"));
        }
    }
}
